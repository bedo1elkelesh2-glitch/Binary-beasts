const db = require('../../connectors/db');
// check function getUser in milestone 3 description and session.js
const {getUser} = require('../../utils/session');
const {requireAdmin, requireShopOwner, requireCustomer, requireShopOwnerOrAdmin} = require('../../middleware/roleAuth');
// getUser takes only one input of req 
// await getUser(req);

function handlePrivateBackendApi(app) {
  
  // Test endpoint
  app.get('/test' , async (req,res) => {
     try{
      return res.status(200).json({ message: "succesful connection", authenticated: true });
     }catch(err){
      console.log("error message", err.message);
      return res.status(400).json({ error: err.message })
     }    
  });

  // ============================================
  // SHOP OWNER ENDPOINTS - Menu Management
  // ============================================

  // Add new menu item (Shop Owner only)
  app.post('/api/v1/menu/items', requireShopOwner, async (req, res) => {
    try {
      const user = req.user;
      
      // Get the truck owned by this user
      const truck = await db.select('*')
        .from('FoodTruck.Trucks')
        .where('ownerId', user.userId)
        .first();

      if (!truck) {
        return res.status(400).send('You do not own any truck');
      }

      const { name, description, price, category, status } = req.body;
      
      if (!name || !price || !category) {
        return res.status(400).send('Name, price, and category are required');
      }

      const newMenuItem = {
        truckId: truck.truckId,
        name,
        description: description || null,
        price: parseFloat(price),
        category,
        status: status || 'available'
      };

      const menuItem = await db('FoodTruck.MenuItems')
        .insert(newMenuItem)
        .returning('*');

      return res.status(201).json(menuItem[0]);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not add menu item');
    }
  });

  // Get all menu items for shop owner's truck
  app.get('/api/v1/menu/items', requireShopOwner, async (req, res) => {
    try {
      const user = req.user;
      
      const truck = await db.select('*')
        .from('FoodTruck.Trucks')
        .where('ownerId', user.userId)
        .first();

      if (!truck) {
        return res.status(400).send('You do not own any truck');
      }

      const menuItems = await db.select('*')
        .from('FoodTruck.MenuItems')
        .where('truckId', truck.truckId)
        .orderBy('category', 'asc')
        .orderBy('name', 'asc');

      return res.status(200).json(menuItems);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not fetch menu items');
    }
  });

  // Update menu item (Shop Owner only)
  app.put('/api/v1/menu/items/:itemId', requireShopOwner, async (req, res) => {
    try {
      const user = req.user;
      const { itemId } = req.params;
      
      // Get the truck owned by this user
      const truck = await db.select('*')
        .from('FoodTruck.Trucks')
        .where('ownerId', user.userId)
        .first();

      if (!truck) {
        return res.status(400).send('You do not own any truck');
      }

      // Verify the menu item belongs to this truck
      const menuItem = await db.select('*')
        .from('FoodTruck.MenuItems')
        .where('itemId', itemId)
        .where('truckId', truck.truckId)
        .first();

      if (!menuItem) {
        return res.status(404).send('Menu item not found or you do not have permission');
      }

      const { name, description, price, category, status } = req.body;
      const updates = {};
      
      if (name !== undefined) updates.name = name;
      if (description !== undefined) updates.description = description;
      if (price !== undefined) updates.price = parseFloat(price);
      if (category !== undefined) updates.category = category;
      if (status !== undefined) updates.status = status;

      const updatedItem = await db('FoodTruck.MenuItems')
        .where('itemId', itemId)
        .update(updates)
        .returning('*');

      return res.status(200).json(updatedItem[0]);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not update menu item');
    }
  });

  // Delete menu item (Shop Owner only)
  app.delete('/api/v1/menu/items/:itemId', requireShopOwner, async (req, res) => {
    try {
      const user = req.user;
      const { itemId } = req.params;
      
      // Get the truck owned by this user
      const truck = await db.select('*')
        .from('FoodTruck.Trucks')
        .where('ownerId', user.userId)
        .first();

      if (!truck) {
        return res.status(400).send('You do not own any truck');
      }

      // Verify the menu item belongs to this truck
      const menuItem = await db.select('*')
        .from('FoodTruck.MenuItems')
        .where('itemId', itemId)
        .where('truckId', truck.truckId)
        .first();

      if (!menuItem) {
        return res.status(404).send('Menu item not found or you do not have permission');
      }

      await db('FoodTruck.MenuItems')
        .where('itemId', itemId)
        .del();

      return res.status(200).send('Menu item deleted successfully');
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not delete menu item');
    }
  });

  // ============================================
  // ADMIN ENDPOINTS - User & Shop Management
  // ============================================

  // Get all users (Admin only)
  app.get('/api/v1/admin/users', requireAdmin, async (req, res) => {
    try {
      const users = await db.select('*')
        .from('FoodTruck.Users')
        .orderBy('createdAt', 'desc');
      
      return res.status(200).json(users);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not fetch users');
    }
  });

  // Get all shops/trucks (Admin only)
  app.get('/api/v1/admin/trucks', requireAdmin, async (req, res) => {
    try {
      const trucks = await db.select(
        'FoodTruck.Trucks.*',
        'FoodTruck.Users.name as ownerName',
        'FoodTruck.Users.email as ownerEmail'
      )
        .from('FoodTruck.Trucks')
        .innerJoin('FoodTruck.Users', 'FoodTruck.Trucks.ownerId', 'FoodTruck.Users.userId')
        .orderBy('FoodTruck.Trucks.createdAt', 'desc');
      
      return res.status(200).json(trucks);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not fetch trucks');
    }
  });

  // Get all orders (Admin only)
  app.get('/api/v1/admin/orders', requireAdmin, async (req, res) => {
    try {
      const orders = await db.select(
        'FoodTruck.Orders.*',
        'FoodTruck.Users.name as customerName',
        'FoodTruck.Users.email as customerEmail',
        'FoodTruck.Trucks.truckName'
      )
        .from('FoodTruck.Orders')
        .innerJoin('FoodTruck.Users', 'FoodTruck.Orders.userId', 'FoodTruck.Users.userId')
        .innerJoin('FoodTruck.Trucks', 'FoodTruck.Orders.truckId', 'FoodTruck.Trucks.truckId')
        .orderBy('FoodTruck.Orders.createdAt', 'desc');
      
      return res.status(200).json(orders);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not fetch orders');
    }
  });

  // Get order details with items (Admin only)
  app.get('/api/v1/admin/orders/:orderId', requireAdmin, async (req, res) => {
    try {
      const { orderId } = req.params;
      
      const order = await db.select(
        'FoodTruck.Orders.*',
        'FoodTruck.Users.name as customerName',
        'FoodTruck.Users.email as customerEmail',
        'FoodTruck.Trucks.truckName'
      )
        .from('FoodTruck.Orders')
        .innerJoin('FoodTruck.Users', 'FoodTruck.Orders.userId', 'FoodTruck.Users.userId')
        .innerJoin('FoodTruck.Trucks', 'FoodTruck.Orders.truckId', 'FoodTruck.Trucks.truckId')
        .where('FoodTruck.Orders.orderId', orderId)
        .first();

      if (!order) {
        return res.status(404).send('Order not found');
      }

      const orderItems = await db.select(
        'FoodTruck.OrderItems.*',
        'FoodTruck.MenuItems.name as itemName'
      )
        .from('FoodTruck.OrderItems')
        .innerJoin('FoodTruck.MenuItems', 'FoodTruck.OrderItems.itemId', 'FoodTruck.MenuItems.itemId')
        .where('FoodTruck.OrderItems.orderId', orderId);

      return res.status(200).json({
        order: order,
        items: orderItems
      });
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not fetch order details');
    }
  });

  // Update user (Admin only) - manage customers
  app.put('/api/v1/admin/users/:userId', requireAdmin, async (req, res) => {
    try {
      const { userId } = req.params;
      const { name, email, role, birthDate } = req.body;

      // Check if user exists
      const user = await db.select('*')
        .from('FoodTruck.Users')
        .where('userId', userId)
        .first();

      if (!user) {
        return res.status(404).send('User not found');
      }

      const updates = {};
      if (name !== undefined) updates.name = name;
      if (email !== undefined) updates.email = email;
      if (role !== undefined) updates.role = role;
      if (birthDate !== undefined) updates.birthDate = birthDate;

      const updatedUser = await db('FoodTruck.Users')
        .where('userId', userId)
        .update(updates)
        .returning('*');

      return res.status(200).json(updatedUser[0]);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not update user');
    }
  });

  // Delete user (Admin only)
  app.delete('/api/v1/admin/users/:userId', requireAdmin, async (req, res) => {
    try {
      const { userId } = req.params;

      // Prevent deleting yourself
      if (req.user.userId == userId) {
        return res.status(400).send('Cannot delete your own account');
      }

      const user = await db.select('*')
        .from('FoodTruck.Users')
        .where('userId', userId)
        .first();

      if (!user) {
        return res.status(404).send('User not found');
      }

      await db('FoodTruck.Users')
        .where('userId', userId)
        .del();

      return res.status(200).send('User deleted successfully');
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not delete user');
    }
  });

  // Update truck/shop (Admin only) - manage shops
  app.put('/api/v1/admin/trucks/:truckId', requireAdmin, async (req, res) => {
    try {
      const { truckId } = req.params;
      const { truckName, truckLogo, truckStatus, orderStatus } = req.body;

      const truck = await db.select('*')
        .from('FoodTruck.Trucks')
        .where('truckId', truckId)
        .first();

      if (!truck) {
        return res.status(404).send('Truck not found');
      }

      const updates = {};
      if (truckName !== undefined) updates.truckName = truckName;
      if (truckLogo !== undefined) updates.truckLogo = truckLogo;
      if (truckStatus !== undefined) updates.truckStatus = truckStatus;
      if (orderStatus !== undefined) updates.orderStatus = orderStatus;

      const updatedTruck = await db('FoodTruck.Trucks')
        .where('truckId', truckId)
        .update(updates)
        .returning('*');

      return res.status(200).json(updatedTruck[0]);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not update truck');
    }
  });

  // Delete truck/shop (Admin only)
  app.delete('/api/v1/admin/trucks/:truckId', requireAdmin, async (req, res) => {
    try {
      const { truckId } = req.params;

      const truck = await db.select('*')
        .from('FoodTruck.Trucks')
        .where('truckId', truckId)
        .first();

      if (!truck) {
        return res.status(404).send('Truck not found');
      }

      await db('FoodTruck.Trucks')
        .where('truckId', truckId)
        .del();

      return res.status(200).send('Truck deleted successfully');
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not delete truck');
    }
  });

  // ============================================
  // CUSTOMER ENDPOINTS (if needed)
  // ============================================

  // Get current user profile
  app.get('/api/v1/user/profile', async (req, res) => {
    try {
      const user = await getUser(req);
      if (!user) {
        return res.status(401).send('Unauthorized');
      }
      return res.status(200).json(user);
    } catch (e) {
      console.log(e.message);
      return res.status(400).send('Could not fetch profile');
    }
  });


























  




};



module.exports = {handlePrivateBackendApi};
