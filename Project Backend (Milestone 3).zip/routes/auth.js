const express = require('express');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');

const router = express.Router();

// Generate JWT token
const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET || 'fallback_secret', {
    expiresIn: '24h'
  });
};

// Register route
router.post('/register', [
  body('universityId').notEmpty().withMessage('University ID is required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('role').isIn(['customer', 'shop', 'admin']).withMessage('Invalid role'),
  body('referralCode').notEmpty().withMessage('Referral code is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { universityId, email, password, phoneNumber, username, role, referralCode, shopName, shopContact } = req.body;

    // Verify referral code
    const validCodes = {
      customer: process.env.CUSTOMER_REFERRAL_CODE || '9652',
      shop: process.env.VENDOR_REFERRAL_CODE || '159753',
      admin: process.env.ADMIN_REFERRAL_CODE || '30941'
    };

    if (referralCode !== validCodes[role]) {
      return res.status(400).json({ message: 'Invalid referral code for this role' });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ universityId });
    if (existingUser) {
      return res.status(400).json({ message: 'User with this University ID already exists' });
    }

    // Check email uniqueness for customers
    if (role === 'customer' && email) {
      const existingEmail = await User.findOne({ email });
      if (existingEmail) {
        return res.status(400).json({ message: 'Email already registered' });
      }
    }

    // Check username uniqueness for admins
    if (role === 'admin' && username) {
      const existingUsername = await User.findOne({ username });
      if (existingUsername) {
        return res.status(400).json({ message: 'Username already taken' });
      }
    }

    // Create new user
    const userData = {
      universityId,
      password,
      role
    };

    if (role === 'customer') {
      userData.email = email;
      userData.phoneNumber = phoneNumber;
    } else if (role === 'shop') {
      userData.phoneNumber = phoneNumber;
      userData.shopName = shopName;
      userData.shopContact = shopContact;
    } else if (role === 'admin') {
      userData.username = username;
    }

    const user = new User(userData);
    await user.save();

    const token = generateToken(user._id);

    res.status(201).json({
      token,
      user: {
        id: user._id,
        universityId: user.universityId,
        email: user.email,
        username: user.username,
        role: user.role,
        shopName: user.shopName,
        shopContact: user.shopContact
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error during registration' });
  }
});

// Login route
router.post('/login', [
  body('universityId').notEmpty().withMessage('University ID or username is required'),
  body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { universityId, password } = req.body;
    const identifier = typeof universityId === 'string' ? universityId.trim() : universityId;

    // Allow login via universityId, username, or email
    let user = await User.findOne({ universityId: identifier });
    if (!user) {
      user = await User.findOne({ username: identifier });
    }
    if (!user && identifier && identifier.includes('@')) {
      user = await User.findOne({ email: identifier.toLowerCase() });
    }
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(400).json({ message: 'Account is deactivated' });
    }

    const token = generateToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        universityId: user.universityId,
        email: user.email,
        username: user.username,
        role: user.role,
        shopName: user.shopName,
        shopContact: user.shopContact
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error during login' });
  }
});

module.exports = router;
