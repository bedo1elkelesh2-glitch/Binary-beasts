const { v4 } = require('uuid');
const db = require('../../connectors/db');
const axios = require('axios');

function handlePublicBackendApi(app) {

    // Register HTTP endpoint to create new user (Sign Up)
    app.post('/api/v1/user', async function(req, res) {
      // Check if user already exists in the system
      const userExists = await db.select('*').from('FoodTruck.Users').where('email', req.body.email);
      //console.log(userExists)
      if (userExists.length > 0) {
        return res.status(400).send('user exists');
      }
      
      try {
        const { name, email, password, role, birthDate } = req.body;
        
        // Validate required fields
        if (!name || !email || !password) {
          return res.status(400).send('Name, email, and password are required');
        }

        // Default role to 'customer' if not provided (prevent unauthorized admin creation)
        const userRole = role === 'admin' ? 'customer' : (role || 'customer');
        
        const newUser = {
          name,
          email,
          password,
          role: userRole,
          birthDate: birthDate || null
        };
        
        const user = await db('FoodTruck.Users').insert(newUser).returning('*');
        return res.status(200).json(user);
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not register user');
      }
    });

    // Register HTTP endpoint to create new user
    app.post('/api/v1/user/login', async function(req, res) {
      // get users credentials from the JSON body
      const { email, password } = req.body
      if (!email) {
        // If the email is not present, return an HTTP unauthorized code
        return res.status(400).send('email is required');
      }
      if (!password) {
        // If the password is not present, return an HTTP unauthorized code
        return res.status(400).send('Password is required');
      }

      // validate the provided password against the password in the database
      // if invalid, send an unauthorized code
      let user = await db.select('*').from('FoodTruck.Users').where('email', email);
      if (user.length == 0) {
        return res.status(400).send('user does not exist');
      }
      user = user[0];
      if (user.password !== password) {
        return res.status(400).send('Password does not match');
      }

      // set the expiry time as 30 minutes after the current time
      const token = v4();
      const currentDateTime = new Date();
      const expiresAt = new Date(+currentDateTime + 18000000); // expire in 3 minutes

      // create a session containing information about the user and expiry time
      const session = {
        userId: user.userId,
        token,
        expiresAt,
      };
      try {
        await db('FoodTruck.Sessions').insert(session);
        // In the response, set a cookie on the client with the name "session_cookie"
        // and the value as the UUID we generated. We also set the expiration time.
        axios.defaults.headers.common['Cookie'] = `session_token=${token};expires=${expiresAt}`;
        return res.cookie("session_token", token, { expires: expiresAt }).status(200).send('login successful');
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not register user');
      }
    });

    // ============================================
    // PUBLIC ENDPOINTS - Browse Restaurants & Menus
    // ============================================

    // Get all available food trucks (restaurants)
    app.get('/api/v1/trucks', async function(req, res) {
      try {
        const trucks = await db.select('*')
          .from('FoodTruck.Trucks')
          .where('truckStatus', 'available')
          .orderBy('createdAt', 'desc');
        
        return res.status(200).json(trucks);
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not fetch trucks');
      }
    });

    // Get a specific truck by ID
    app.get('/api/v1/trucks/:truckId', async function(req, res) {
      try {
        const { truckId } = req.params;
        const truck = await db.select('*')
          .from('FoodTruck.Trucks')
          .where('truckId', truckId)
          .first();
        
        if (!truck) {
          return res.status(404).send('Truck not found');
        }
        
        return res.status(200).json(truck);
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not fetch truck');
      }
    });

    // Get menu items for a specific truck
    app.get('/api/v1/trucks/:truckId/menu', async function(req, res) {
      try {
        const { truckId } = req.params;
        
        // Verify truck exists
        const truck = await db.select('*')
          .from('FoodTruck.Trucks')
          .where('truckId', truckId)
          .first();
        
        if (!truck) {
          return res.status(404).send('Truck not found');
        }

        // Get menu items
        const menuItems = await db.select('*')
          .from('FoodTruck.MenuItems')
          .where('truckId', truckId)
          .where('status', 'available')
          .orderBy('category', 'asc')
          .orderBy('name', 'asc');
        
        return res.status(200).json({
          truck: truck,
          menuItems: menuItems
        });
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not fetch menu');
      }
    });

    // Get all menu items (for browsing)
    app.get('/api/v1/menu', async function(req, res) {
      try {
        const menuItems = await db.select(
          'FoodTruck.MenuItems.*',
          'FoodTruck.Trucks.truckName',
          'FoodTruck.Trucks.truckLogo'
        )
          .from('FoodTruck.MenuItems')
          .innerJoin('FoodTruck.Trucks', 'FoodTruck.MenuItems.truckId', 'FoodTruck.Trucks.truckId')
          .where('FoodTruck.MenuItems.status', 'available')
          .where('FoodTruck.Trucks.truckStatus', 'available')
          .orderBy('FoodTruck.Trucks.truckName', 'asc')
          .orderBy('FoodTruck.MenuItems.category', 'asc');
        
        return res.status(200).json(menuItems);
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not fetch menu items');
      }
    });

};


module.exports = {handlePublicBackendApi};
