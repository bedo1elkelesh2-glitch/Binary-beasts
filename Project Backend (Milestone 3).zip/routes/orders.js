const express = require('express');
const { auth, authorize } = require('../middleware/auth');
const Order = require('../models/Order');
const Item = require('../models/Item');

const router = express.Router();

// Get all orders (admin only)
router.get('/all', auth, authorize('admin'), async (req, res) => {
  try {
    const orders = await Order.find()
      .populate('customerId', 'universityId email')
      .populate('items.itemId', 'name shopName')
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    console.error('Orders fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get orders for current customer
router.get('/my-orders', auth, authorize('customer'), async (req, res) => {
  try {
    const orders = await Order.find({ customerId: req.user._id })
      .populate('items.itemId', 'name image')
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    console.error('Customer orders fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get orders for shop items (shop owners)
router.get('/shop-orders', auth, authorize('shop'), async (req, res) => {
  try {
    const orders = await Order.find({
      'items.shopId': req.user._id
    })
    .populate('customerId', 'universityId email')
    .populate('items.itemId', 'name image')
    .sort({ createdAt: -1 });
    
    // Filter to only show items from this shop
    const filteredOrders = orders.map(order => ({
      ...order.toObject(),
      items: order.items.filter(item => item.shopId.toString() === req.user._id.toString())
    }));
    
    res.json(filteredOrders);
  } catch (error) {
    console.error('Shop orders fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create new order (customers only)
router.post('/', auth, authorize('customer'), async (req, res) => {
  try {
    const { items, orderNotes, pickupTime } = req.body;
    
    if (!items || items.length === 0) {
      return res.status(400).json({ message: 'Order must contain at least one item' });
    }
    
    // Verify all items exist and calculate total
    let totalAmount = 0;
    const orderItems = [];
    
    for (const orderItem of items) {
      const item = await Item.findById(orderItem.itemId);
      if (!item) {
        return res.status(400).json({ message: `Item ${orderItem.itemId} not found` });
      }
      
      if (!item.isAvailable) {
        return res.status(400).json({ message: `Item "${item.name}" is currently unavailable` });
      }
      
      let itemTotal = item.price * orderItem.quantity;
      
      // Add extras cost
      if (orderItem.extras && orderItem.extras.length > 0) {
        const extrasTotal = orderItem.extras.reduce((sum, extra) => sum + (extra.price || 0), 0);
        itemTotal += extrasTotal * orderItem.quantity;
      }
      
      totalAmount += itemTotal;
      
      orderItems.push({
        itemId: item._id,
        itemName: item.name,
        quantity: orderItem.quantity,
        price: item.price,
        extras: orderItem.extras || [],
        shopId: item.shopId ? item.shopId.toString() : undefined,
        shopName: item.shopName
      });
    }
    
    const orderCode = `ORD-${Date.now().toString().slice(-6)}`;

    const order = new Order({
      customerId: req.user._id,
      customerEmail: req.user.email,
      customerPhone: req.user.phoneNumber,
      items: orderItems,
      totalAmount,
      orderCode,
      orderNotes: orderNotes || '',
      pickupTime: pickupTime ? new Date(pickupTime) : undefined
    });
    
    await order.save();
    
    const populatedOrder = await Order.findById(order._id)
      .populate('customerId', 'universityId email')
      .populate('items.itemId', 'name image');
    
    // TODO: Integrate SMS provider here. Stub log for now.
    try {
      const smsText = `GIU Order ${order.orderCode}\n` +
        order.items.map(i => `- ${i.itemName} x${i.quantity}`).join('\n') +
        `\nTotal: ${order.totalAmount} EGP`;
      console.log('SMS to', order.customerPhone, ':', smsText);
    } catch (e) {
      console.error('SMS stub error:', e);
    }

    res.status(201).json(populatedOrder);
  } catch (error) {
    console.error('Order creation error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update order status (shops can update their items' orders)
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status, estimatedPickupTime, prepTimeMinutes } = req.body;
    const validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled'];
    
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Check permissions
    if (req.user.role === 'shop') {
      // Shop can only update orders that contain their items
      const hasShopItems = order.items.some(item => 
        item.shopId.toString() === req.user._id.toString()
      );
      if (!hasShopItems) {
        return res.status(403).json({ message: 'Unauthorized to update this order' });
      }
    } else if (req.user.role === 'customer') {
      // Customers can only cancel their own pending orders
      if (order.customerId.toString() !== req.user._id.toString()) {
        return res.status(403).json({ message: 'Unauthorized to update this order' });
      }
      if (status !== 'cancelled' || order.status !== 'pending') {
        return res.status(400).json({ message: 'Can only cancel pending orders' });
      }
    } else if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized' });
    }
    
    if (status) {
      order.status = status;
    }
    if (typeof estimatedPickupTime === 'string' && estimatedPickupTime.trim().length > 0) {
      order.estimatedPickupTime = estimatedPickupTime.trim();
    }
    if (typeof prepTimeMinutes === 'number' && prepTimeMinutes > 0) {
      order.prepTimeMinutes = prepTimeMinutes;
    }
    await order.save();
    
    const updatedOrder = await Order.findById(order._id)
      .populate('customerId', 'universityId email')
      .populate('items.itemId', 'name image');
    
    res.json(updatedOrder);
  } catch (error) {
    console.error('Order status update error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get single order
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('customerId', 'universityId email')
      .populate('items.itemId', 'name image shopName');
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Check permissions
    if (req.user.role === 'customer' && order.customerId._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Unauthorized' });
    } else if (req.user.role === 'shop') {
      const hasShopItems = order.items.some(item => 
        item.shopId.toString() === req.user._id.toString()
      );
      if (!hasShopItems) {
        return res.status(403).json({ message: 'Unauthorized' });
      }
    }
    
    res.json(order);
  } catch (error) {
    console.error('Order fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
