-- ====================================
-- Create Test Data for Food Truck System
-- ====================================
-- Run this in pgAdmin Query Tool to create test data
-- ====================================

-- Step 1: Create a test shop owner user (if doesn't exist)
-- Replace 'shopowner@example.com' with your email if you want to use an existing user
INSERT INTO "FoodTruck"."Users" ("name", "email", "password", "role")
VALUES ('Shop Owner', 'shopowner@example.com', 'password123', 'truckOwner')
ON CONFLICT ("email") DO NOTHING;

-- Step 2: Get the userId (you'll need this for the next step)
-- Run this query to find your userId:
-- SELECT "userId", "name", "email", "role" FROM "FoodTruck"."Users" WHERE "role" = 'truckOwner';

-- Step 3: Create a food truck (replace <userId> with actual userId from Step 2)
-- Example: If userId is 1, use:
INSERT INTO "FoodTruck"."Trucks" ("truckName", "ownerId", "truckLogo", "truckStatus", "orderStatus")
VALUES 
  ('Tasty Burgers', (SELECT "userId" FROM "FoodTruck"."Users" WHERE "email" = 'shopowner@example.com' LIMIT 1), 'https://example.com/logo1.png', 'available', 'available'),
  ('Pizza Paradise', (SELECT "userId" FROM "FoodTruck"."Users" WHERE "email" = 'shopowner@example.com' LIMIT 1), 'https://example.com/logo2.png', 'available', 'available'),
  ('Taco Fiesta', (SELECT "userId" FROM "FoodTruck"."Users" WHERE "email" = 'shopowner@example.com' LIMIT 1), 'https://example.com/logo3.png', 'available', 'available')
ON CONFLICT DO NOTHING;

-- Step 4: Add menu items to the trucks
-- Get truckId first: SELECT "truckId", "truckName" FROM "FoodTruck"."Trucks";

-- Add items to Tasty Burgers (assuming truckId = 1)
INSERT INTO "FoodTruck"."MenuItems" ("truckId", "name", "description", "price", "category", "status")
VALUES 
  (1, 'Classic Cheeseburger', 'Juicy beef patty with cheese, lettuce, tomato', 9.99, 'Burgers', 'available'),
  (1, 'Bacon Burger', 'Cheeseburger with crispy bacon', 11.99, 'Burgers', 'available'),
  (1, 'French Fries', 'Crispy golden fries', 4.99, 'Sides', 'available'),
  (1, 'Onion Rings', 'Crispy battered onion rings', 5.99, 'Sides', 'available'),
  (1, 'Coca Cola', 'Refreshing cola drink', 2.99, 'Drinks', 'available')
ON CONFLICT DO NOTHING;

-- Add items to Pizza Paradise (assuming truckId = 2)
INSERT INTO "FoodTruck"."MenuItems" ("truckId", "name", "description", "price", "category", "status")
VALUES 
  (2, 'Margherita Pizza', 'Classic pizza with tomato and mozzarella', 12.99, 'Pizza', 'available'),
  (2, 'Pepperoni Pizza', 'Pizza with pepperoni and cheese', 14.99, 'Pizza', 'available'),
  (2, 'Garlic Bread', 'Warm garlic bread sticks', 5.99, 'Sides', 'available'),
  (2, 'Caesar Salad', 'Fresh romaine lettuce with caesar dressing', 8.99, 'Salads', 'available')
ON CONFLICT DO NOTHING;

-- Add items to Taco Fiesta (assuming truckId = 3)
INSERT INTO "FoodTruck"."MenuItems" ("truckId", "name", "description", "price", "category", "status")
VALUES 
  (3, 'Beef Taco', 'Seasoned ground beef in soft shell', 3.99, 'Tacos', 'available'),
  (3, 'Chicken Taco', 'Grilled chicken in soft shell', 3.99, 'Tacos', 'available'),
  (3, 'Taco Combo (3 tacos)', 'Any 3 tacos with chips and salsa', 10.99, 'Combos', 'available'),
  (3, 'Guacamole', 'Fresh avocado dip', 4.99, 'Sides', 'available'),
  (3, 'Horchata', 'Traditional rice drink', 3.99, 'Drinks', 'available')
ON CONFLICT DO NOTHING;

-- Verify data was created
SELECT 'Trucks:' as info;
SELECT "truckId", "truckName", "ownerId", "truckStatus" FROM "FoodTruck"."Trucks";

SELECT 'Menu Items:' as info;
SELECT m."itemId", m."name", m."price", t."truckName" 
FROM "FoodTruck"."MenuItems" m
JOIN "FoodTruck"."Trucks" t ON m."truckId" = t."truckId";

