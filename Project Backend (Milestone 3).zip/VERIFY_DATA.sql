-- ====================================
-- Verify Data in Database
-- ====================================
-- Run these queries in pgAdmin to check what data exists
-- ====================================

-- 1. Check if any users exist
SELECT 'Users:' as info;
SELECT "userId", "name", "email", "role" FROM "FoodTruck"."Users";

-- 2. Check if any trucks exist
SELECT 'Trucks:' as info;
SELECT "truckId", "truckName", "ownerId", "truckStatus", "orderStatus" 
FROM "FoodTruck"."Trucks";

-- 3. Check if any menu items exist
SELECT 'Menu Items:' as info;
SELECT m."itemId", m."name", m."price", t."truckName", t."truckId"
FROM "FoodTruck"."MenuItems" m
JOIN "FoodTruck"."Trucks" t ON m."truckId" = t."truckId";

-- 4. If trucks exist but endpoint still fails, check truckStatus
SELECT 'Trucks with status:' as info;
SELECT "truckId", "truckName", "truckStatus" 
FROM "FoodTruck"."Trucks"
WHERE "truckStatus" = 'available';

