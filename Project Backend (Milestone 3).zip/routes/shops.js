const express = require('express');
const { auth, authorize } = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// Get all shops
router.get('/', async (req, res) => {
  try {
    const shops = await User.find({ role: 'shop', isActive: true })
      .select('shopName shopContact phoneNumber createdAt');
    res.json(shops);
  } catch (error) {
    console.error('Shops fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get shop by ID
router.get('/:id', async (req, res) => {
  try {
    const shop = await User.findOne({ 
      _id: req.params.id, 
      role: 'shop', 
      isActive: true 
    }).select('shopName shopContact phoneNumber createdAt');
    
    if (!shop) {
      return res.status(404).json({ message: 'Shop not found' });
    }
    
    res.json(shop);
  } catch (error) {
    console.error('Shop fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
