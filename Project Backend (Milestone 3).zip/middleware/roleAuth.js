const {getUser} = require('../utils/session');

// Middleware to check if user has required role
function requireRole(allowedRoles) {
  return async (req, res, next) => {
    try {
      const user = await getUser(req);
      
      if (!user) {
        return res.status(401).json({ error: 'Unauthorized - Please login' });
      }

      if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({ 
          error: 'Forbidden - Insufficient permissions',
          required: allowedRoles,
          current: user.role
        });
      }

      // Attach user to request for use in endpoints
      req.user = user;
      next();
    } catch (error) {
      console.error('Role auth error:', error.message);
      return res.status(401).json({ error: 'Unauthorized' });
    }
  };
}

// Helper middleware for admin only
const requireAdmin = requireRole(['admin']);

// Helper middleware for shop owner only
const requireShopOwner = requireRole(['truckOwner']);

// Helper middleware for customer only
const requireCustomer = requireRole(['customer']);

// Helper middleware for shop owner or admin
const requireShopOwnerOrAdmin = requireRole(['truckOwner', 'admin']);

module.exports = {
  requireRole,
  requireAdmin,
  requireShopOwner,
  requireCustomer,
  requireShopOwnerOrAdmin
};

