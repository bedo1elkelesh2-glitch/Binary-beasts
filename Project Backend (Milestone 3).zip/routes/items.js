const express = require('express');
const multer = require('multer');
const path = require('path');
const { auth, authorize } = require('../middleware/auth');
const Item = require('../models/Item');
const fs = require('fs');

const router = express.Router();

// Configure multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 20 * 1024 * 1024 // 20MB limit for 4K photos
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Get all items (with optional filtering)
router.get('/', async (req, res) => {
  try {
    const { type, shopId } = req.query;
    const filter = {};
    
    if (type && ['food', 'drink'].includes(type)) {
      filter.type = type;
    }
    
    if (shopId) {
      filter.shopId = shopId;
    }
    
    const items = await Item.find(filter)
      .populate('shopId', 'shopName shopContact')
      .sort({ createdAt: -1 });
    
    res.json(items);
  } catch (error) {
    console.error('Items fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get items by shop (for shop owners)
router.get('/my-items', auth, authorize('shop'), async (req, res) => {
  try {
    const items = await Item.find({ shopId: req.user._id })
      .sort({ createdAt: -1 });
    res.json(items);
  } catch (error) {
    console.error('Shop items fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get single item
router.get('/:id', async (req, res) => {
  try {
    const item = await Item.findById(req.params.id)
      .populate('shopId', 'shopName shopContact phoneNumber');
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    res.json(item);
  } catch (error) {
    console.error('Item fetch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create new item (shop owners only)
router.post('/', auth, authorize('shop'), (req, res, next) => {
  // Handle multer errors
  upload.single('image')(req, res, (err) => {
    if (err) {
      console.error('Multer error:', err);
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ message: 'File too large. Maximum size is 20MB for 4K photos.' });
      }
      if (err.message === 'Only image files are allowed') {
        return res.status(400).json({ message: 'Only image files (JPEG, JPG, PNG, GIF) are allowed.' });
      }
      return res.status(400).json({ message: 'File upload error: ' + err.message });
    }
    next();
  });
}, async (req, res) => {
  try {
    console.log('=== CREATE ITEM REQUEST ===');
    console.log('Request body:', req.body);
    console.log('User:', req.user);
    
    const { name, description, price, type, extras, pickupTime } = req.body;
    
    console.log('Extracted fields:');
    console.log('- name:', name);
    console.log('- description:', description);
    console.log('- price:', price);
    console.log('- type:', type);
    console.log('- pickupTime:', pickupTime);
    console.log('- extras:', extras);
    
    // Parse extras if it's a string
    let parsedExtras = [];
    if (extras) {
      try {
        parsedExtras = typeof extras === 'string' ? JSON.parse(extras) : extras;
      } catch (e) {
        console.log('Error parsing extras:', e.message);
        parsedExtras = [];
      }
    }
    
    const itemData = {
      name,
      description,
      price: parseFloat(price),
      type,
      extras: parsedExtras,
      shopId: req.user._id,
      shopName: req.user.shopName,
      pickupTime: pickupTime || '15-20 minutes'
    };
    
    console.log('Item data to save:', itemData);
    console.log('File info:', req.file ? {
      filename: req.file.filename,
      originalname: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size
    } : 'No file uploaded');
    
    if (req.file) {
      itemData.image = `/uploads/${req.file.filename}`;
      console.log('Image path set:', itemData.image);
    } else {
      console.log('No image file provided, using default');
    }
    
    const item = new Item(itemData);
    console.log('Attempting to save item...');
    await item.save();
    console.log('Item saved successfully:', item);
    
    res.status(201).json(item);
  } catch (error) {
    console.error('Item creation error:', error);
    console.error('Error details:', {
      name: error.name,
      message: error.message,
      code: error.code,
      errors: error.errors
    });
    res.status(500).json({ 
      message: 'Server error',
      error: error.message,
      details: error.errors || error.message
    });
  }
});

// Update item (shop owners only)
router.put('/:id', auth, authorize('shop'), (req, res, next) => {
  // Handle multer errors
  upload.single('image')(req, res, (err) => {
    if (err) {
      console.error('Multer error on update:', err);
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ message: 'File too large. Maximum size is 20MB for 4K photos.' });
      }
      if (err.message === 'Only image files are allowed') {
        return res.status(400).json({ message: 'Only image files (JPEG, JPG, PNG, GIF) are allowed.' });
      }
      return res.status(400).json({ message: 'File upload error: ' + err.message });
    }
    next();
  });
}, async (req, res) => {
  try {
    const item = await Item.findOne({ _id: req.params.id, shopId: req.user._id });
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found or unauthorized' });
    }
    
    const { name, description, price, type, extras, pickupTime, isAvailable } = req.body;
    
    // Parse extras if it's a string
    let parsedExtras = item.extras;
    if (extras !== undefined) {
      try {
        parsedExtras = typeof extras === 'string' ? JSON.parse(extras) : extras;
      } catch (e) {
        parsedExtras = item.extras;
      }
    }
    
    const updates = {};
    if (name !== undefined) updates.name = name;
    if (description !== undefined) updates.description = description;
    if (price !== undefined) updates.price = parseFloat(price);
    if (type !== undefined) updates.type = type;
    if (extras !== undefined) updates.extras = parsedExtras;
    if (pickupTime !== undefined) updates.pickupTime = pickupTime;
    if (isAvailable !== undefined) updates.isAvailable = isAvailable;
    
    if (req.file) {
      updates.image = `/uploads/${req.file.filename}`;
    }
    
    const updatedItem = await Item.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );
    
    res.json(updatedItem);
  } catch (error) {
    console.error('Item update error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Toggle item availability (shop owners only)
router.patch('/:id/toggle-availability', auth, authorize('shop'), async (req, res) => {
  try {
    const item = await Item.findOne({ _id: req.params.id, shopId: req.user._id });
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found or unauthorized' });
    }
    
    item.isAvailable = !item.isAvailable;
    await item.save();
    
    res.json(item);
  } catch (error) {
    console.error('Item availability toggle error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin delete any item
router.delete('/admin/:id', auth, authorize('admin'), async (req, res) => {
  try {
    console.log('Admin delete request - User role:', req.user.role);
    console.log('Admin delete request - Item ID:', req.params.id);
    
    const item = await Item.findById(req.params.id);
    
    if (!item) {
      console.log('Item not found');
      return res.status(404).json({ message: 'Item not found' });
    }
    
    console.log('Item found, proceeding with deletion');
    await Item.findByIdAndDelete(req.params.id);
    res.json({ message: 'Item deleted successfully' });
  } catch (error) {
    console.error('Admin item deletion error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete item (shop owners and admins)
router.delete('/:id', auth, async (req, res) => {
  try {
    console.log('=== DELETE ITEM REQUEST ===');
    console.log('User role:', req.user.role);
    console.log('User ID:', req.user._id);
    console.log('Item ID:', req.params.id);
    console.log('Authorization header:', req.headers.authorization);
    
    let item;
    
    if (req.user.role === 'admin') {
      // Admins can delete any item
      console.log('Admin attempting to delete item');
      item = await Item.findById(req.params.id);
    } else if (req.user.role === 'shop') {
      // Shop owners can only delete their own items
      console.log('Shop owner attempting to delete item');
      item = await Item.findOne({ _id: req.params.id, shopId: req.user._id });
    } else {
      console.log('Access denied - Invalid role:', req.user.role);
      return res.status(403).json({ message: 'Access denied. Invalid role.' });
    }
    
    if (!item) {
      console.log('Item not found');
      return res.status(404).json({ message: 'Item not found or unauthorized' });
    }
    
    console.log('Item found, proceeding with deletion');
    await Item.findByIdAndDelete(req.params.id);
    console.log('Item deleted successfully');
    res.json({ message: 'Item deleted successfully' });
  } catch (error) {
    console.error('Item deletion error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
