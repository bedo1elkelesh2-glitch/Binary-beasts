const express = require('express');
const app = express();
const bodyParser = require("body-parser");
const {handlePrivateBackendApi} = require('./routes/private/api');
const {handlePublicBackendApi} = require('./routes/public/api');
const {handlePublicFrontEndView} = require('./routes/public/view');
const {handlePrivateFrontEndView} = require('./routes/private/view');
const {authMiddleware} = require('./middleware/auth');
require('dotenv').config();
const PORT = process.env.PORT || 3001;


// view engine setup
app.set('views', './views');
app.set('view engine', 'hjs');
app.use(express.static('./public'));

// CORS middleware for browser requests
app.use((req, res, next) => {
  // Allow requests from any origin (for local testing)
  const origin = req.headers.origin;
  res.header('Access-Control-Allow-Origin', origin || '*');
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Cookie');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Handle post requests
app.use(express.json());
app.use(express.urlencoded({ extended: true}));

// Health check endpoint (public, no auth required)
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Server is running' });
});

handlePublicFrontEndView(app);
handlePublicBackendApi(app);
app.use(authMiddleware);
handlePrivateFrontEndView(app);
handlePrivateBackendApi(app);

app.listen(PORT, () => {
    console.log(`Server is now listening at port ${PORT} on http://localhost:${PORT}/`);
});